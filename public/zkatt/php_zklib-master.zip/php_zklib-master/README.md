# PHP ZKLib #

Attendance Machine Library for PHP with a connection to the network using the UDP protocol and port 4370

[Donation! ![](http://i.imgur.com/2tqfhMO.png?1)](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=DCSTC5GTWLBAN&lc=ID&item_name=donywahyuisp&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHosted)

## NOW ##
> This library is now beginning to be redeveloped and will come with complete documentation
